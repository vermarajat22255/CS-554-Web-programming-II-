import React from "react";
import "../App.css"
function Page404 (){

  return (
    <div className="cap-first-letter">
      <h1 className="list">
        <dt> Error 404: Page Not Found</dt>
        <br />
      </h1>
    </div>
  );
};
export default Page404;