const locationData = require("./location");

module.exports = {
    locationData
};